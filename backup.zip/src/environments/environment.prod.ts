export const environment = {
  production: true
};

export const firebaseEnvironment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyCkjjDvkGPIUMxH4VLlXq7tInbT17JgNPQ',
    authDomain: 'glaring-fire-74.firebaseapp.com',
    databaseURL: 'https://glaring-fire-74.firebaseio.com',
    projectId: 'glaring-fire-74',
    storageBucket: 'glaring-fire-74.appspot.com',
    messagingSenderId: '260024706779'
  }
};